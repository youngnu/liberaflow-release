# Liberaflow Installer PowerShell Script
param(
    [switch]$Uninstall
)

$AppName = "Liberaflow"
$InstallPath = "$env:PROGRAMFILES\$AppName"
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path

if ($Uninstall) {
    Write-Host "Uninstalling $AppName..." -ForegroundColor Yellow
    
    # 바로가기 제거
    $StartMenuShortcut = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\$AppName.lnk"
    $DesktopShortcut = "$env:USERPROFILE\Desktop\$AppName.lnk"
    
    if (Test-Path $StartMenuShortcut) { Remove-Item $StartMenuShortcut -Force }
    if (Test-Path $DesktopShortcut) { Remove-Item $DesktopShortcut -Force }
    
    # 설치 폴더 제거
    if (Test-Path $InstallPath) {
        Remove-Item $InstallPath -Recurse -Force
    }
    
    Write-Host "$AppName has been uninstalled successfully!" -ForegroundColor Green
}
else {
    Write-Host "Installing $AppName..." -ForegroundColor Cyan
    
    # 관리자 권한 확인
    if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
    {
        Write-Host "Administrator privileges required. Restarting with elevated permissions..." -ForegroundColor Yellow
        Start-Process powershell.exe -ArgumentList "-File `"$($MyInvocation.MyCommand.Path)`"" -Verb RunAs
        exit
    }
    
    # 설치 디렉터리 생성
    if (!(Test-Path $InstallPath)) {
        New-Item -ItemType Directory -Path $InstallPath -Force
    }
    
    # 파일들 복사 (현재 디렉터리의 모든 파일)
    Write-Host "Copying files to $InstallPath..." -ForegroundColor Yellow
    
    $SourceFiles = Get-ChildItem -Path $ScriptPath -Exclude "installer.ps1", "*.zip" -Recurse
    foreach ($File in $SourceFiles) {
        $DestPath = $File.FullName.Replace($ScriptPath, $InstallPath)
        $DestDir = Split-Path -Parent $DestPath
        
        if (!(Test-Path $DestDir)) {
            New-Item -ItemType Directory -Path $DestDir -Force | Out-Null
        }
        
        Copy-Item -Path $File.FullName -Destination $DestPath -Force
    }
    
    # 시작 메뉴 바로가기 생성
    $WshShell = New-Object -comObject WScript.Shell
    $StartMenuShortcut = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\$AppName.lnk"
    $Shortcut = $WshShell.CreateShortcut($StartMenuShortcut)
    $Shortcut.TargetPath = "$InstallPath\liberaflow.exe"
    $Shortcut.WorkingDirectory = $InstallPath
    $Shortcut.Description = "Advanced automation and productivity application"
    $Shortcut.Save()
    
    # 바탕화면 바로가기 생성
    $DesktopShortcut = "$env:USERPROFILE\Desktop\$AppName.lnk"
    $Shortcut = $WshShell.CreateShortcut($DesktopShortcut)
    $Shortcut.TargetPath = "$InstallPath\liberaflow.exe"
    $Shortcut.WorkingDirectory = $InstallPath
    $Shortcut.Description = "Advanced automation and productivity application"
    $Shortcut.Save()
    
    Write-Host "`n$AppName has been installed successfully!" -ForegroundColor Green
    Write-Host "You can find $AppName in:" -ForegroundColor White
    Write-Host "  - Start Menu" -ForegroundColor Gray
    Write-Host "  - Desktop shortcut" -ForegroundColor Gray
    Write-Host "  - $InstallPath" -ForegroundColor Gray
    
    # 설치 완료 후 앱 실행 여부 확인
    $RunApp = Read-Host "`nWould you like to run $AppName now? (y/N)"
    if ($RunApp -eq 'y' -or $RunApp -eq 'Y') {
        Start-Process "$InstallPath\liberaflow.exe"
    }
}

Write-Host "`nPress any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")